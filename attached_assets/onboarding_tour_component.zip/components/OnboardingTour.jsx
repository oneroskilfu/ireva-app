
import React, { useState } from 'react';
import Joyride from 'react-joyride';

const OnboardingTour = () => {
  const [run, setRun] = useState(true);

  const steps = [
    {
      target: '.sidebar-home',
      content: 'Welcome to your dashboard! Start by exploring your home overview.',
    },
    {
      target: '.sidebar-projects',
      content: 'Here you can view and manage your investment projects.',
    },
    {
      target: '.sidebar-wallet',
      content: 'Your wallet shows your available balance and transaction history.',
    },
    {
      target: '.profile-section',
      content: 'Update your KYC, preferences and account info here.',
    },
    {
      target: '.notification-bell',
      content: 'Get real-time updates about investments and KYC approvals.',
    },
  ];

  return (
    <Joyride
      steps={steps}
      continuous
      scrollToFirstStep
      showProgress
      showSkipButton
      run={run}
      styles={{
        options: {
          zIndex: 10000,
          arrowColor: '#fff',
          backgroundColor: '#222',
          textColor: '#fff',
        },
      }}
    />
  );
};

export default OnboardingTour;
