
import React from 'react';
import OnboardingTour from '../components/OnboardingTour';

const Dashboard = () => {
  return (
    <div className="dashboard-container">
      <OnboardingTour />

      <div className="sidebar-home">Dashboard Overview</div>
      <div className="sidebar-projects">Projects</div>
      <div className="sidebar-wallet">Wallet</div>
      <div className="profile-section">Profile</div>
      <div className="notification-bell">Notifications</div>
    </div>
  );
};

export default Dashboard;
