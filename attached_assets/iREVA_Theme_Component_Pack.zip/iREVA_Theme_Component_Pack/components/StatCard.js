
// components/StatCard.js
import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';

const StatCard = ({ title, value }) => (
  <Card sx={{ p: 2, boxShadow: 3, borderRadius: 2 }}>
    <CardContent>
      <Typography variant="h6">{title}</Typography>
      <Typography variant="h4" color="primary">{value}</Typography>
    </CardContent>
  </Card>
);

export default StatCard;
