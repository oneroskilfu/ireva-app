import React, { useState } from 'react';
import { Box, Typography, Button, TextField, Paper } from '@mui/material';
import axios from 'axios';

const AdminWalletFundingPanel = () => {
  const [amount, setAmount] = useState('');
  const [recipient, setRecipient] = useState('');
  const [message, setMessage] = useState('');

  const handleFund = async () => {
    try {
      const res = await axios.post('/api/admin/crypto/fund-wallet', { amount, recipient });
      setMessage('Wallet funded successfully.');
    } catch (err) {
      setMessage('Funding failed. Please try again.');
    }
  };

  return (
    <Paper sx={{ padding: 4, maxWidth: 500, margin: 'auto' }}>
      <Typography variant="h6" gutterBottom>Admin Wallet Funding</Typography>
      <TextField label="Amount" fullWidth margin="normal" value={amount} onChange={e => setAmount(e.target.value)} />
      <TextField label="Recipient Wallet ID" fullWidth margin="normal" value={recipient} onChange={e => setRecipient(e.target.value)} />
      <Button variant="contained" color="primary" onClick={handleFund}>Fund Wallet</Button>
      {message && <Typography sx={{ mt: 2 }}>{message}</Typography>}
    </Paper>
  );
};

export default AdminWalletFundingPanel;