const express = require('express');
const router = express.Router();

// Dummy crypto wallet balances (in real app, use a database or wallet API)
let wallets = {
  'investor123': { balance: 0 }
};

router.post('/admin/crypto/fund-wallet', (req, res) => {
  const { recipient, amount } = req.body;
  if (!wallets[recipient]) {
    wallets[recipient] = { balance: 0 };
  }
  wallets[recipient].balance += parseFloat(amount);
  console.log(`[Admin] Funded ${amount} to wallet ${recipient}`);
  return res.status(200).json({ success: true, newBalance: wallets[recipient].balance });
});

module.exports = router;