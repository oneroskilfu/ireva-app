import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip);

function Dashboard() {
  const [users, setUsers] = useState([]);
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem('token');
    axios.get('http://localhost:5000/api/users', { headers: { Authorization: `Bearer ${token}` }})
      .then(res => setUsers(res.data));

    axios.get('http://localhost:5000/api/projects', { headers: { Authorization: `Bearer ${token}` }})
      .then(res => setProjects(res.data));
  }, []);

  const chartData = {
    labels: projects.map(p => p.title),
    datasets: [{
      label: 'Funding Goal',
      data: projects.map(p => p.fundingGoal),
      backgroundColor: 'rgba(75, 192, 192, 0.6)',
    }]
  };

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>Total Users: {users.length}</p>
      <p>Total Projects: {projects.length}</p>
      <Bar data={chartData} />
    </div>
  );
}

export default Dashboard;