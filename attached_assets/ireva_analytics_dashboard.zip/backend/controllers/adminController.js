
const Investment = require('../models/Investment');
const KYC = require('../models/KYC');
const Project = require('../models/Project');
const User = require('../models/User');

exports.getAdminStats = async (req, res) => {
  const totalUsers = await User.countDocuments();
  const verifiedKYC = await KYC.countDocuments({ status: 'Approved' });
  const totalProjects = await Project.countDocuments();
  const totalInvestments = await Investment.aggregate([
    { $group: { _id: null, total: { $sum: "$amount" } } }
  ]);
  const totalROI = await Investment.aggregate([
    { $group: { _id: null, total: { $sum: "$roiPaid" } } }
  ]);

  const monthlyInvestments = await Investment.aggregate([
    {
      $group: {
        _id: { $substr: ['$createdAt', 0, 7] },
        total: { $sum: '$amount' }
      }
    },
    { $sort: { _id: 1 } }
  ]);

  res.json({
    summary: {
      totalUsers,
      verifiedKYC,
      totalProjects,
      totalInvestments: totalInvestments[0]?.total || 0,
      totalROI: totalROI[0]?.total || 0
    },
    monthlyInvestments: monthlyInvestments.map(item => ({
      month: item._id,
      total: item.total
    }))
  });
};
