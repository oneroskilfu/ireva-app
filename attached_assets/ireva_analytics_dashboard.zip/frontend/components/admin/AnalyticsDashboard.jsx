
import { useEffect, useState } from 'react';
import { Grid, Paper, Typography } from '@mui/material';
import { Bar } from 'react-chartjs-2';
import axios from 'axios';

const AnalyticsDashboard = () => {
  const [stats, setStats] = useState({});
  const [monthlyData, setMonthlyData] = useState([]);

  useEffect(() => {
    const fetchStats = async () => {
      const token = localStorage.getItem('token');
      const res = await axios.get('/api/admin/stats', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setStats(res.data.summary);
      setMonthlyData(res.data.monthlyInvestments);
    };
    fetchStats();
  }, []);

  const chartData = {
    labels: monthlyData.map(item => item.month),
    datasets: [{
      label: 'Monthly Investments',
      data: monthlyData.map(item => item.total),
      backgroundColor: 'rgba(53, 162, 235, 0.6)',
    }]
  };

  return (
    <Grid container spacing={3}>
      {[ 
        ['Users', stats.totalUsers],
        ['KYCs Verified', stats.verifiedKYC],
        ['Projects', stats.totalProjects],
        ['Investments', `₦${stats.totalInvestments}`],
        ['ROI Paid', `₦${stats.totalROI}`]
      ].map(([label, value], i) => (
        <Grid item xs={12} md={4} key={i}>
          <Paper sx={{ padding: 3 }}>
            <Typography variant="h6">{label}</Typography>
            <Typography variant="h4">{value || 0}</Typography>
          </Paper>
        </Grid>
      ))}

      <Grid item xs={12}>
        <Paper sx={{ padding: 3 }}>
          <Typography variant="h6" gutterBottom>Monthly Investment Trend</Typography>
          <Bar data={chartData} />
        </Paper>
      </Grid>
    </Grid>
  );
};

export default AnalyticsDashboard;
