
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const LoginPage = () => {
  const [role, setRole] = useState('investor');
  const navigate = useNavigate();

  const login = () => {
    const user = { role };
    localStorage.setItem('user', JSON.stringify(user));
    navigate(role === 'admin' ? '/admin' : '/dashboard');
  };

  return (
    <div>
      <h2>Login</h2>
      <select value={role} onChange={e => setRole(e.target.value)}>
        <option value="investor">Investor</option>
        <option value="admin">Admin</option>
      </select>
      <button onClick={login}>Login</button>
    </div>
  );
};

export default LoginPage;
