
import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => (
  <nav>
    <Link to="/">Login</Link> | 
    <Link to="/dashboard">Investor Dashboard</Link> | 
    <Link to="/admin">Admin</Link>
  </nav>
);

export default Navbar;
