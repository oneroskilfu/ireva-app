
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';
import LoginPage from './pages/LoginPage';
import AdminDashboard from './pages/admin/AdminDashboard';
import InvestorDashboard from './pages/investor/InvestorDashboard';
import KYCPortal from './pages/investor/KYCPortal';
import ProjectList from './pages/investor/ProjectList';
import Wallet from './pages/investor/Wallet';
import Settings from './pages/common/Settings';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/admin" element={<ProtectedRoute role="admin"><AdminDashboard /></ProtectedRoute>} />
        <Route path="/dashboard" element={<ProtectedRoute role="investor"><InvestorDashboard /></ProtectedRoute>} />
        <Route path="/kyc" element={<ProtectedRoute role="investor"><KYCPortal /></ProtectedRoute>} />
        <Route path="/projects" element={<ProtectedRoute role="investor"><ProjectList /></ProtectedRoute>} />
        <Route path="/wallet" element={<ProtectedRoute role="investor"><Wallet /></ProtectedRoute>} />
        <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
      </Routes>
    </Router>
  );
}

export default App;
