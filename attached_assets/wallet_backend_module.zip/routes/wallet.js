const express = require('express');
const router = express.Router();
const Wallet = require('../models/Wallet');
const Transaction = require('../models/Transaction');
const { authenticateUser } = require('../middleware/auth');

router.get('/', authenticateUser, async (req, res) => {
  const wallet = await Wallet.findOne({ user: req.user._id }) || await Wallet.create({ user: req.user._id });
  const transactions = await Transaction.find({ user: req.user._id }).sort({ date: -1 });
  res.json({ wallet, transactions });
});

router.post('/add', authenticateUser, async (req, res) => {
  const amount = req.body.amount || 0;
  let wallet = await Wallet.findOne({ user: req.user._id });

  if (!wallet) {
    wallet = new Wallet({ user: req.user._id, balance: 0 });
  }

  wallet.balance += amount;
  await wallet.save();

  await Transaction.create({
    user: req.user._id,
    amount,
    type: 'credit',
    status: 'completed'
  });

  res.json({ success: true, wallet });
});

module.exports = router;