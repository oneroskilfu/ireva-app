const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const authRoutes = require('./routes/auth');
const projectRoutes = require('./routes/projects');
const userRoutes = require('./routes/users');
const propertyRoutes = require('./routes/properties');
const investmentRoutes = require('./routes/investments');
const messageRoutes = require('./routes/messages');

dotenv.config();
const app = express();

mongoose.connect(process.env.MONGO_URI);

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/users', userRoutes);
app.use('/api/properties', propertyRoutes);
app.use('/api/investments', investmentRoutes);
app.use('/api/messages', messageRoutes);

app.listen(5000, () => console.log('Server running on port 5000'));