const express = require('express');
const router = express.Router();
const Investment = require('../models/Investment');
const authenticate = require('../middleware/auth');

// GET all investments
router.get('/', authenticate, async (req, res) => {
  const investments = await Investment.find().populate('user').populate('project');
  const data = investments.map(inv => ({
    _id: inv._id,
    user: inv.user?.username || '',
    project: inv.project?.title || '',
    amount: inv.amount,
    date: inv.date
  }));
  res.json(data);
});

// POST new investment
router.post('/', authenticate, async (req, res) => {
  const { project, amount } = req.body;
  const investment = new Investment({
    user: req.user.id,
    project,
    amount
  });
  await investment.save();
  res.status(201).json(investment);
});

// GET ROI tracking data
router.get('/roi', authenticate, async (req, res) => {
  const roiData = [
    { date: '2024-01', roi: 5.1 },
    { date: '2024-02', roi: 6.4 },
    { date: '2024-03', roi: 7.2 }
  ]; // Ideally calculate dynamically
  res.json(roiData);
});

module.exports = router;