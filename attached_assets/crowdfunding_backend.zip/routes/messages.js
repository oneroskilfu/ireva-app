const express = require('express');
const router = express.Router();
const Message = require('../models/Message');
const authenticate = require('../middleware/auth');

// GET all messages
router.get('/', authenticate, async (req, res) => {
  const messages = await Message.find().sort({ sentAt: -1 });
  res.json(messages);
});

// POST send message
router.post('/', authenticate, async (req, res) => {
  const { receiver, content } = req.body;
  const message = new Message({
    sender: req.user.id,
    receiver,
    content
  });
  await message.save();
  res.status(201).json(message);
});

module.exports = router;