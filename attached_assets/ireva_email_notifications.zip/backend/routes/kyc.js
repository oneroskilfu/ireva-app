
const express = require('express');
const router = express.Router();
const { approveKYC } = require('../controllers/kycController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

router.put('/approve/:id', protect, adminOnly, approveKYC);

module.exports = router;
