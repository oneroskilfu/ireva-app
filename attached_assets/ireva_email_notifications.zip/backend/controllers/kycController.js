
const sendEmail = require('../utils/sendEmail');
const User = require('../models/User');
const KYC = require('../models/KYC');

exports.approveKYC = async (req, res) => {
  const kyc = await KYC.findById(req.params.id);
  if (!kyc) return res.status(404).json({ message: 'KYC not found' });

  kyc.status = 'Approved';
  await kyc.save();

  const user = await User.findById(kyc.userId);
  await sendEmail(
    user.email,
    'KYC Approved - Welcome to iREVA',
    `Hello ${user.firstName},\n\nYour KYC has been approved. You can now invest on iREVA.\n\nThanks,\niREVA Team`
  );

  res.json({ message: 'KYC approved and email sent' });
};
