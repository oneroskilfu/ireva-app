import React from 'react';
import { Card, Typography, Grid } from '@mui/material';

const DashboardOverview = () => {
  return (
    <Grid container spacing={2}>
      <Grid item xs={12} sm={6} md={3}>
        <Card variant="outlined" sx={{ padding: 2 }}>
          <Typography variant="h6">Wallet Balance</Typography>
          <Typography variant="h4">₦500,000</Typography>
        </Card>
      </Grid>
      <Grid item xs={12} sm={6} md={3}>
        <Card variant="outlined" sx={{ padding: 2 }}>
          <Typography variant="h6">Total ROI</Typography>
          <Typography variant="h4">₦75,000</Typography>
        </Card>
      </Grid>
      <Grid item xs={12} sm={6} md={3}>
        <Card variant="outlined" sx={{ padding: 2 }}>
          <Typography variant="h6">Active Investments</Typography>
          <Typography variant="h4">3</Typography>
        </Card>
      </Grid>
    </Grid>
  );
};

export default DashboardOverview;
